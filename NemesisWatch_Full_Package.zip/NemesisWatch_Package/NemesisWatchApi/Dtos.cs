namespace NemesisWatchApi
{
    public record ReportViolationRequest(string PlayerId, string CheckName, string Severity, string Details);
    public record ShotRequest(string PlayerId, bool Hit, bool Headshot);
    public record ReactionRequest(string PlayerId, double Milliseconds);
    public record AimSnapRequest(string PlayerId, double DegreesThisTick, bool FollowedByHit);
    public record OpcodeRequest(string PlayerId, int OpcodeValue);
    public record SaveDataRequest(string PlayerId, int Coins, int Level, int LegacyBonusTokens);

    public record ActionResponse(string Action);
    public record OpcodeCheckResponse(bool WasHoneypot, string Action);
    public record SaveDataCheckResponse(bool Accepted, string Action);
}
