using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using NemesisWatch;
using NemesisWatchApi;
using NemesisWatchApi.Data;

var builder = WebApplication.CreateBuilder(args);

// SQLite file lives next to the app — fine for a single-instance MVP
// deployment. See NemesisWatchDbContext's docs for the upgrade path to
// PostgreSQL/SQL Server when you outgrow this.
builder.Services.AddDbContextFactory<NemesisWatchDbContext>(options =>
    options.UseSqlite("Data Source=nemesiswatch.db"));

builder.Services.AddSingleton<TenantRegistry>();

builder.Services.AddCors(options =>
{
    // MVP: wide open so your dashboard frontend (wherever it ends up
    // living) can call this freely during development. Lock this down to
    // your actual dashboard's origin before going live.
    options.AddDefaultPolicy(policy => policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

// --- Rate limiting -----------------------------------------------------
// Partitioned per API key, so one noisy or malicious customer can't starve
// everyone else's traffic. 50 requests/second sliding window is generous
// enough for normal gameplay telemetry (shots, reactions, aim snaps can
// fire often) but stops someone from flooding the endpoint with garbage.
// Tune PermitLimit once you know your real traffic patterns.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
    {
        string key = httpContext.Request.Headers.TryGetValue("X-Api-Key", out var apiKey) && !string.IsNullOrEmpty(apiKey)
            ? apiKey.ToString()
            : httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";

        return RateLimitPartition.GetSlidingWindowLimiter(key, _ => new SlidingWindowRateLimiterOptions
        {
            PermitLimit = 50,
            Window = TimeSpan.FromSeconds(1),
            SegmentsPerWindow = 5,
            QueueLimit = 0
        });
    });
});

var app = builder.Build();
app.UseCors();
app.UseRateLimiter();

// --- API key auth -----------------------------------------------------
// Every request must carry X-Api-Key identifying which customer's game is
// calling. This is intentionally simple for the MVP (a header check
// against the SQLite-backed tenant table) — before real launch, add key
// revocation and per-tenant plan/quota tracking on top of this.
app.Use(async (context, next) =>
{
    if (context.Request.Path.StartsWithSegments("/health"))
    {
        await next();
        return;
    }

    if (!context.Request.Headers.TryGetValue("X-Api-Key", out var apiKey))
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        await context.Response.WriteAsJsonAsync(new { error = "Missing X-Api-Key header" });
        return;
    }

    var registry = context.RequestServices.GetRequiredService<TenantRegistry>();
    var tenant = registry.GetByApiKey(apiKey.ToString());
    if (tenant == null)
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        await context.Response.WriteAsJsonAsync(new { error = "Invalid API key" });
        return;
    }

    context.Items["Tenant"] = tenant;
    await next();
});

TenantContext CurrentTenant(HttpContext ctx) => (TenantContext)ctx.Items["Tenant"]!;

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

// --- Hard-rule violations (forwarded from the customer's own ServerAuthority) ---
app.MapPost("/api/v1/violations/report", (HttpContext ctx, ReportViolationRequest req) =>
{
    if (!Enum.TryParse<ViolationSeverity>(req.Severity, ignoreCase: true, out var severity))
        return Results.BadRequest(new { error = $"Unknown severity '{req.Severity}'" });

    var violation = new Violation
    {
        PlayerId = req.PlayerId,
        CheckName = req.CheckName,
        Severity = severity,
        Details = req.Details,
        ServerTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
    };

    var action = CurrentTenant(ctx).ReportViolation(violation);
    return Results.Ok(new ActionResponse(action.ToString()));
});

// --- Behavioral analytics ---
app.MapPost("/api/v1/behavior/shot", (HttpContext ctx, ShotRequest req) =>
{
    var action = CurrentTenant(ctx).RecordShot(req.PlayerId, req.Hit, req.Headshot);
    return Results.Ok(new ActionResponse(action.ToString()));
});

app.MapPost("/api/v1/behavior/reaction", (HttpContext ctx, ReactionRequest req) =>
{
    var action = CurrentTenant(ctx).RecordReaction(req.PlayerId, req.Milliseconds);
    return Results.Ok(new ActionResponse(action.ToString()));
});

app.MapPost("/api/v1/behavior/aimsnap", (HttpContext ctx, AimSnapRequest req) =>
{
    var action = CurrentTenant(ctx).RecordAimSnap(req.PlayerId, req.DegreesThisTick, req.FollowedByHit);
    return Results.Ok(new ActionResponse(action.ToString()));
});

// --- Honeypots ---
app.MapPost("/api/v1/honeypot/opcode", (HttpContext ctx, OpcodeRequest req) =>
{
    var (wasHoneypot, action) = CurrentTenant(ctx).CheckOpcode(req.PlayerId, req.OpcodeValue);
    return Results.Ok(new OpcodeCheckResponse(wasHoneypot, action.ToString()));
});

app.MapPost("/api/v1/honeypot/savedata", (HttpContext ctx, SaveDataRequest req) =>
{
    var upload = new SaveDataUpload
    {
        PlayerId = req.PlayerId,
        Coins = req.Coins,
        Level = req.Level,
        LegacyBonusTokens = req.LegacyBonusTokens
    };
    var (accepted, action) = CurrentTenant(ctx).CheckSaveData(upload);
    return Results.Ok(new SaveDataCheckResponse(accepted, action.ToString()));
});

// --- Dashboard data (now reading from SQLite, survives restarts) ---
app.MapGet("/api/v1/players/{playerId}/history", (HttpContext ctx, string playerId) =>
{
    return Results.Ok(CurrentTenant(ctx).GetPlayerHistory(playerId));
});

app.MapGet("/api/v1/violations/recent", (HttpContext ctx, int limit) =>
{
    var take = limit <= 0 ? 50 : Math.Min(limit, 500);
    return Results.Ok(CurrentTenant(ctx).GetRecentHistory(take));
});

app.Run();
