using System.Collections.Concurrent;
using Microsoft.EntityFrameworkCore;
using NemesisWatchApi.Data;

namespace NemesisWatchApi
{
    /// <summary>
    /// Maps an API key to the connected game's isolated anti-cheat state.
    /// Tenant identity (which API keys exist, who they belong to) is now
    /// persisted to SQLite — restart the server and your customers' keys
    /// are still valid, unlike the original in-memory MVP version.
    ///
    /// Live scoring state (EscalationPolicy's running per-player scores,
    /// BehaviorAnalyzer's rolling stats) stays in-memory per TenantContext
    /// for now — that's the trade-off documented in the README. What's
    /// durable here is the stuff that actually matters for not losing
    /// customers on a deploy: their key, and the violation history for
    /// their dashboard.
    /// </summary>
    public class TenantRegistry
    {
        private readonly ConcurrentDictionary<string, TenantContext> _liveContexts = new();
        private readonly IDbContextFactory<NemesisWatchDbContext> _dbFactory;

        public TenantRegistry(IDbContextFactory<NemesisWatchDbContext> dbFactory)
        {
            _dbFactory = dbFactory;
            EnsureSeedTenants();
        }

        private void EnsureSeedTenants()
        {
            using var db = _dbFactory.CreateDbContext();
            db.Database.EnsureCreated();

            // Two throwaway test keys so you can start hitting the API
            // immediately. Delete these (or just stop using them) once real
            // onboarding exists — they're only inserted if not already present,
            // so this is safe to run on every startup.
            SeedIfMissing(db, "nw_test_key_alpha", "test-studio-alpha", "Test Studio Alpha");
            SeedIfMissing(db, "nw_test_key_beta", "test-studio-beta", "Test Studio Beta");
        }

        private void SeedIfMissing(NemesisWatchDbContext db, string apiKey, string tenantId, string displayName)
        {
            if (db.Tenants.Any(t => t.ApiKey == apiKey)) return;

            db.Tenants.Add(new TenantEntity
            {
                ApiKey = apiKey,
                TenantId = tenantId,
                DisplayName = displayName,
                CreatedAtUtc = DateTime.UtcNow
            });
            db.SaveChanges();
        }

        /// <summary>
        /// Issues a brand new API key for a customer. Call this from your
        /// (not-yet-built) real signup flow instead of hand-editing seed data.
        /// </summary>
        public string RegisterNewTenant(string tenantId, string displayName)
        {
            string apiKey = "nw_" + Guid.NewGuid().ToString("N");

            using var db = _dbFactory.CreateDbContext();
            db.Tenants.Add(new TenantEntity
            {
                ApiKey = apiKey,
                TenantId = tenantId,
                DisplayName = displayName,
                CreatedAtUtc = DateTime.UtcNow
            });
            db.SaveChanges();

            return apiKey;
        }

        public TenantContext GetByApiKey(string apiKey)
        {
            if (_liveContexts.TryGetValue(apiKey, out var existing))
                return existing;

            using var db = _dbFactory.CreateDbContext();
            var entity = db.Tenants.FirstOrDefault(t => t.ApiKey == apiKey);
            if (entity == null)
                return null; // invalid key — caller returns 401

            // First request for this key since the process started — build a
            // fresh live context and cache it in memory for subsequent calls.
            var context = new TenantContext(entity.TenantId, entity.DisplayName, apiKey, _dbFactory);
            _liveContexts[apiKey] = context;
            return context;
        }
    }
}
