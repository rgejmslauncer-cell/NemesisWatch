using Microsoft.EntityFrameworkCore;

namespace NemesisWatchApi.Data
{
    public class TenantEntity
    {
        public string ApiKey { get; set; }       // primary key
        public string TenantId { get; set; }
        public string DisplayName { get; set; }
        public DateTime CreatedAtUtc { get; set; }
    }

    public class ViolationEntity
    {
        public int Id { get; set; }              // auto-increment primary key
        public string TenantApiKey { get; set; }
        public string PlayerId { get; set; }
        public string CheckName { get; set; }
        public string Severity { get; set; }
        public string Details { get; set; }
        public double ServerTime { get; set; }
        public string ResultingAction { get; set; }
        public DateTime RecordedAtUtc { get; set; }
    }

    /// <summary>
    /// SQLite is deliberately the starting choice here: zero setup (it's
    /// just a file on disk), which matters for getting a first real
    /// customer running today. It will NOT hold up under real concurrent
    /// load or a multi-instance deployment behind a load balancer — when
    /// you outgrow it, migrating this same EF Core model to PostgreSQL or
    /// SQL Server is a connection-string-and-provider-package change, not
    /// a rewrite, because the schema is defined here rather than hand-written
    /// SQL scattered through the app.
    /// </summary>
    public class NemesisWatchDbContext : DbContext
    {
        public DbSet<TenantEntity> Tenants { get; set; }
        public DbSet<ViolationEntity> Violations { get; set; }

        public NemesisWatchDbContext(DbContextOptions<NemesisWatchDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TenantEntity>().HasKey(t => t.ApiKey);
            modelBuilder.Entity<ViolationEntity>().HasIndex(v => new { v.TenantApiKey, v.PlayerId });
        }
    }
}
