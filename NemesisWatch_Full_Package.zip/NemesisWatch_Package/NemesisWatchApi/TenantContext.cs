using Microsoft.EntityFrameworkCore;
using NemesisWatch;
using NemesisWatch.Behavioral;
using NemesisWatchApi.Data;

namespace NemesisWatchApi
{
    /// <summary>
    /// Everything Nemesis Watch tracks for ONE connected game. Every
    /// customer gets their own instance of this — a player ID in customer
    /// A's game and the same string in customer B's game are completely
    /// unrelated, since each TenantContext has its own EscalationPolicy and
    /// BehaviorAnalyzer with their own internal player dictionaries.
    ///
    /// Violation history is now written through to SQLite on every
    /// evaluation, so it survives a server restart and can back a real
    /// dashboard. The live scoring state itself (EscalationPolicy's
    /// decaying per-player scores) stays in memory for the life of the
    /// process — see TenantRegistry's docs for why that trade-off is fine
    /// for now.
    ///
    /// Every public method here evaluates its violation (if any) EXACTLY
    /// ONCE against the escalation policy — see the scoped subscribe/call/
    /// unsubscribe pattern below. Evaluating twice would silently
    /// double-count a violation against the player's score.
    /// </summary>
    public class TenantContext
    {
        public string TenantId { get; }
        public string DisplayName { get; set; }
        public string ApiKey { get; }

        public EscalationPolicy Escalation { get; } = new();
        public BehaviorAnalyzer Behavior { get; } = new();
        public HoneypotOpcodeGuard HoneypotOpcodes { get; } = new();
        public SaveDataHoneypot HoneypotSaveData { get; } = new();

        private readonly IDbContextFactory<NemesisWatchDbContext> _dbFactory;

        public TenantContext(string tenantId, string displayName, string apiKey, IDbContextFactory<NemesisWatchDbContext> dbFactory)
        {
            TenantId = tenantId;
            DisplayName = displayName;
            ApiKey = apiKey;
            _dbFactory = dbFactory;
        }

        private EscalationAction RecordAndReturn(Violation violation)
        {
            var action = Escalation.Evaluate(violation);

            using var db = _dbFactory.CreateDbContext();
            db.Violations.Add(new ViolationEntity
            {
                TenantApiKey = ApiKey,
                PlayerId = violation.PlayerId,
                CheckName = violation.CheckName,
                Severity = violation.Severity.ToString(),
                Details = violation.Details,
                ServerTime = violation.ServerTime,
                ResultingAction = action.ToString(),
                RecordedAtUtc = DateTime.UtcNow
            });
            db.SaveChanges();

            return action;
        }

        /// <summary>
        /// For violations the game itself already detected and formed
        /// (movement/damage/hit checks from ServerAuthority running inside
        /// the customer's own game server) — they just forward the finding
        /// here for centralized scoring and dashboard visibility.
        /// </summary>
        public EscalationAction ReportViolation(Violation violation) => RecordAndReturn(violation);

        public EscalationAction RecordShot(string playerId, bool hit, bool headshot)
        {
            Behavior.RecordShot(playerId, hit, headshot);
            return EscalationAction.None; // RecordShot never raises a flag by itself, only feeds accuracy stats
        }

        public EscalationAction RecordReaction(string playerId, double milliseconds)
        {
            Violation captured = null;
            void Handler(Violation v) => captured = v;

            Behavior.OnBehavioralFlag += Handler;
            Behavior.RecordReactionTime(playerId, milliseconds);
            Behavior.OnBehavioralFlag -= Handler;

            return captured != null ? RecordAndReturn(captured) : EscalationAction.None;
        }

        public EscalationAction RecordAimSnap(string playerId, double degreesThisTick, bool followedByHit)
        {
            Violation captured = null;
            void Handler(Violation v) => captured = v;

            Behavior.OnBehavioralFlag += Handler;
            Behavior.RecordAimSnap(playerId, degreesThisTick, followedByHit);
            Behavior.OnBehavioralFlag -= Handler;

            return captured != null ? RecordAndReturn(captured) : EscalationAction.None;
        }

        public (bool wasHoneypot, EscalationAction action) CheckOpcode(string playerId, int opcodeValue)
        {
            Violation captured = null;
            void Handler(Violation v) => captured = v;

            HoneypotOpcodes.OnHoneypotTriggered += Handler;
            bool wasHoneypot = HoneypotOpcodes.CheckIncomingOpcode(playerId, opcodeValue);
            HoneypotOpcodes.OnHoneypotTriggered -= Handler;

            var action = captured != null ? RecordAndReturn(captured) : EscalationAction.None;
            return (wasHoneypot, action);
        }

        public (bool accepted, EscalationAction action) CheckSaveData(SaveDataUpload upload)
        {
            Violation captured = null;
            void Handler(Violation v) => captured = v;

            HoneypotSaveData.OnHoneypotTriggered += Handler;
            bool accepted = HoneypotSaveData.Validate(upload);
            HoneypotSaveData.OnHoneypotTriggered -= Handler;

            var action = captured != null ? RecordAndReturn(captured) : EscalationAction.None;
            return (accepted, action);
        }

        public List<ViolationEntity> GetPlayerHistory(string playerId)
        {
            using var db = _dbFactory.CreateDbContext();
            return db.Violations
                .Where(v => v.TenantApiKey == ApiKey && v.PlayerId == playerId)
                .OrderByDescending(v => v.ServerTime)
                .ToList();
        }

        public List<ViolationEntity> GetRecentHistory(int limit)
        {
            using var db = _dbFactory.CreateDbContext();
            return db.Violations
                .Where(v => v.TenantApiKey == ApiKey)
                .OrderByDescending(v => v.ServerTime)
                .Take(limit)
                .ToList();
        }
    }
}
