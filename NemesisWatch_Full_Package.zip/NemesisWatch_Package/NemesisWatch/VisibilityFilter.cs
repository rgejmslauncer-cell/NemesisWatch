using System.Collections.Generic;
using UnityEngine;

namespace NemesisWatch
{
    /// <summary>
    /// Closes the ESP/wallhack gap that pure hit-validation can't touch.
    /// Wallhacks don't need to cheat physics — they just read data the game
    /// already has in memory. If the server never sends that data in the
    /// first place, there's nothing for the cheat to read.
    ///
    /// Call this right before you serialize the world-state snapshot for a
    /// given client, and only include the players this method returns.
    /// Everyone else simply doesn't exist in that client's packet.
    /// </summary>
    public class VisibilityFilter
    {
        // Beyond this range, don't bother raycasting — nobody needs to see
        // that far anyway, and it saves a lot of wasted checks.
        public float MaxVisibilityRange = 150f;

        // Reuse the same layer mask you configured on ServerAuthority for
        // the wall-hit check, so "blocked by a wall" means the same thing
        // in both systems.
        public LayerMask LevelGeometryMask = ~0;

        public float ObserverEyeHeight = 1.6f;
        private const float Skin = 0.05f;

        /// <summary>
        /// Returns the subset of allPlayers that 'observer' can actually see
        /// right now. Excludes the observer itself.
        /// </summary>
        public List<PlayerState> GetVisiblePlayersFor(PlayerState observer, IEnumerable<PlayerState> allPlayers)
        {
            var visible = new List<PlayerState>();
            Vector3 origin = observer.Position + Vector3.up * ObserverEyeHeight;

            foreach (var other in allPlayers)
            {
                if (other == observer) continue;
                if (other.Health <= 0) continue; // dead players don't need to be tracked either

                float distance = Vector3.Distance(observer.Position, other.Position);
                if (distance > MaxVisibilityRange) continue;

                Vector3 target = other.Position + Vector3.up * ObserverEyeHeight;
                Vector3 direction = (target - origin).normalized;
                float castDistance = Vector3.Distance(origin, target);

                bool blocked = Physics.Raycast(origin, direction, castDistance - Skin, LevelGeometryMask);
                if (!blocked)
                    visible.Add(other);
            }

            return visible;
        }

        /// <summary>
        /// Same idea, but for team-based games: teammates are always
        /// visible on the HUD/minimap regardless of line of sight, so only
        /// filter enemies. Wire your team-check into isEnemy.
        /// </summary>
        public List<PlayerState> GetVisibleEnemiesFor(
            PlayerState observer,
            IEnumerable<PlayerState> allPlayers,
            System.Func<PlayerState, PlayerState, bool> isEnemy)
        {
            var result = new List<PlayerState>();
            foreach (var candidate in GetVisiblePlayersFor(observer, allPlayers))
            {
                if (isEnemy(observer, candidate))
                    result.Add(candidate);
            }
            return result;
        }
    }
}
