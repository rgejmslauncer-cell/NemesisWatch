using System;

namespace NemesisWatch.Behavioral
{
    /// <summary>
    /// Tracks a running mean and standard deviation for a stream of values
    /// using Welford's online algorithm — no need to store every sample,
    /// which matters when you're doing this for every player, every match.
    ///
    /// Two of these get used per stat in practice: one seeded from your
    /// whole player population (the baseline for "what's normal here") and
    /// one per-player (to catch someone who's normal for the population but
    /// suddenly deviates hard from their own established pattern — e.g. a
    /// smurf-suspicious jump, or legit skill improvement vs. a sudden
    /// discontinuity that looks like a cheat got turned on mid-session).
    /// </summary>
    public class RollingStat
    {
        private long _count;
        private double _mean;
        private double _m2; // sum of squared differences from the mean

        public long SampleCount => _count;
        public double Mean => _mean;
        public double StdDev => _count > 1 ? Math.Sqrt(_m2 / (_count - 1)) : 0;

        public void Add(double value)
        {
            _count++;
            double delta = value - _mean;
            _mean += delta / _count;
            double delta2 = value - _mean;
            _m2 += delta * delta2;
        }

        /// <summary>
        /// How many standard deviations 'value' sits from the current mean.
        /// Returns 0 until there's enough history to mean anything — a
        /// z-score computed from 3 samples is noise, not a signal.
        /// </summary>
        public double ZScore(double value, long minimumSamples = 20)
        {
            if (_count < minimumSamples || StdDev < 0.0001)
                return 0;

            return (value - _mean) / StdDev;
        }
    }
}
