namespace NemesisWatch.Behavioral
{
    /// <summary>
    /// The behavioral fingerprint the analyzer builds up for one player over
    /// a session. Nothing here is inherently damning on its own — a
    /// genuinely great player has fast reactions and high accuracy too. The
    /// analyzer's job is spotting combinations and consistency that don't
    /// look like any human's actual variance, not any single good stat.
    /// </summary>
    public class PlayerBehaviorProfile
    {
        public string PlayerId;

        public long TotalShotsFired;
        public long TotalHits;
        public long TotalHeadshots;

        // Reaction time: milliseconds between a target becoming visible/valid
        // and the player's first shot fired at it.
        public RollingStat ReactionTimeMs = new RollingStat();

        // Aim-snap: degrees of view rotation in a single tick when acquiring
        // a target. Humans curve toward a target over several frames; a
        // hard instant snap to exactly on-target is the aimbot signature.
        public RollingStat AimSnapDegreesPerTick = new RollingStat();

        // Post-snap accuracy: of the shots that followed a large snap, what
        // fraction were hits/headshots. A human who happens to flick fast
        // still misses sometimes; a locked-on aimbot barely ever does.
        public RollingStat PostSnapHitRate = new RollingStat();

        public double AccuracyRate => TotalShotsFired == 0 ? 0 : (double)TotalHits / TotalShotsFired;
        public double HeadshotRate => TotalHits == 0 ? 0 : (double)TotalHeadshots / TotalHits;

        public double AnomalyScore;
        public int ConsecutiveAnomalousWindows;
    }
}
