using System;
using System.Collections.Generic;
using NemesisWatch;

namespace NemesisWatch.Behavioral
{
    /// <summary>
    /// Feeds live gameplay events into per-player behavioral profiles and a
    /// shared population baseline, then scores how far each player deviates
    /// from what's statistically normal for your actual playerbase — not
    /// from some hardcoded "humans can't react faster than Xms" number,
    /// which varies wildly by game, input device, and monitor refresh rate.
    ///
    /// Design choices worth understanding before you tune this:
    /// - Every anomaly check requires a minimum sample count (see RollingStat)
    ///   before it can fire at all, so a player's first few minutes never
    ///   get flagged off noise.
    /// - The anomaly score decays on normal behavior and only accumulates on
    ///   deviation, so one suspicious flick doesn't flag anyone — sustained
    ///   inhuman consistency does. This mirrors the same
    ///   accumulate-then-decay shape as EscalationPolicy's scoring, but
    ///   scaled for a much noisier signal.
    /// - Output severity is deliberately capped at Medium — this system
    ///   produces leads for replay review, not verdicts. Pair a behavioral
    ///   flag with an actual recorded replay of the match before acting on it.
    /// </summary>
    public class BehaviorAnalyzer
    {
        private readonly Dictionary<string, PlayerBehaviorProfile> _profiles = new();

        // Population-wide baselines, fed by every player's samples. This is
        // what "normal" actually means for your specific game, weapons and
        // playerbase — don't seed these with numbers from a different game.
        private readonly RollingStat _populationReactionTime = new();
        private readonly RollingStat _populationAimSnap = new();

        // How fast the anomaly score forgets past deviation vs. how much
        // weight one anomalous sample adds. Tune these once you have real
        // match data — these are a reasonable starting point, not gospel.
        private const double AnomalyDecay = 0.92;
        private const double ReactionAnomalyWeight = 6.0;
        private const double SnapAnomalyWeight = 10.0;

        private const double FlagThreshold = 40.0;

        public event Action<Violation> OnBehavioralFlag;

        private PlayerBehaviorProfile GetOrCreate(string playerId)
        {
            if (!_profiles.TryGetValue(playerId, out var profile))
            {
                profile = new PlayerBehaviorProfile { PlayerId = playerId };
                _profiles[playerId] = profile;
            }
            return profile;
        }

        public void RecordShot(string playerId, bool hit, bool headshot)
        {
            var profile = GetOrCreate(playerId);
            profile.TotalShotsFired++;
            if (hit) profile.TotalHits++;
            if (hit && headshot) profile.TotalHeadshots++;
        }

        /// <summary>
        /// Call when a player fires at a target that only just became
        /// visible/valid — pass the elapsed time since it appeared.
        /// </summary>
        public void RecordReactionTime(string playerId, double milliseconds)
        {
            var profile = GetOrCreate(playerId);
            profile.ReactionTimeMs.Add(milliseconds);
            _populationReactionTime.Add(milliseconds);

            double z = _populationReactionTime.ZScore(milliseconds);

            // Reaction time being LOW is the suspicious direction — a large
            // negative z-score means "reacted much faster than everyone
            // else typically does."
            bool anomalous = z < -2.5;
            ApplyDecayOrWeight(profile, anomalous, ReactionAnomalyWeight, "ReactionTime",
                $"{milliseconds:F0}ms (z={z:F2} vs population)");
        }

        /// <summary>
        /// Call whenever the player's view rotates sharply toward a target
        /// in a single tick — pass the rotation magnitude and whether the
        /// following shot(s) hit. A big snap that also lands consistently
        /// is the actual aimbot signature; a big snap alone can just be a
        /// fast flick that then misses, which humans do all the time.
        /// </summary>
        public void RecordAimSnap(string playerId, double degreesThisTick, bool followedByHit)
        {
            var profile = GetOrCreate(playerId);
            profile.AimSnapDegreesPerTick.Add(degreesThisTick);
            profile.PostSnapHitRate.Add(followedByHit ? 1.0 : 0.0);
            _populationAimSnap.Add(degreesThisTick);

            double z = _populationAimSnap.ZScore(degreesThisTick);
            bool largeSnap = z > 3.0;

            // Require BOTH an unusually large snap AND that it landed —
            // this is the combination that's actually hard to explain with
            // skill alone, rather than either fact in isolation.
            bool anomalous = largeSnap && followedByHit;
            ApplyDecayOrWeight(profile, anomalous, SnapAnomalyWeight, "AimSnap",
                $"{degreesThisTick:F1} deg/tick (z={z:F2}), hit={followedByHit}");
        }

        private void ApplyDecayOrWeight(PlayerBehaviorProfile profile, bool anomalous, double weight, string checkName, string details)
        {
            if (anomalous)
            {
                profile.AnomalyScore += weight;
                profile.ConsecutiveAnomalousWindows++;
            }
            else
            {
                profile.AnomalyScore *= AnomalyDecay;
                profile.ConsecutiveAnomalousWindows = 0;
            }

            if (profile.AnomalyScore >= FlagThreshold)
            {
                OnBehavioralFlag?.Invoke(new Violation
                {
                    PlayerId = profile.PlayerId,
                    CheckName = $"StatisticalAnomaly:{checkName}",
                    Severity = ViolationSeverity.Medium, // capped — this is a lead, not proof
                    Details = details,
                    ServerTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
                });

                // Reset after flagging so the same sustained pattern doesn't
                // spam a flag every single sample once past threshold —
                // let the reviewer/escalation policy handle the pacing.
                profile.AnomalyScore = 0;
            }
        }

        public PlayerBehaviorProfile GetProfile(string playerId) => GetOrCreate(playerId);
    }
}
