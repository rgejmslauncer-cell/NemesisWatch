using System;

namespace NemesisWatch
{
    /// <summary>
    /// Some players cheat by editing local save files directly rather than
    /// touching live memory — unlocking currency, items, or progression in
    /// a save that then syncs up to the server. This honeypot is a field
    /// that exists in the save file format but that legitimate game code
    /// never writes a nonzero value into. A save-editing tool scanning the
    /// file for "numbers that look like currency/progress" has no way to
    /// know this field is fake, and editing it is the tell.
    /// </summary>
    public class SaveDataUpload
    {
        public string PlayerId;
        public int Coins;
        public int Level;

        // Bait field. Real save files written by the actual game always
        // have this at 0 — nothing in legitimate game logic increments it.
        // Name it like a plausible bonus/legacy field so an editor tool
        // doesn't skip over it as obviously irrelevant.
        public int LegacyBonusTokens;
    }

    public class SaveDataHoneypot
    {
        public event Action<Violation> OnHoneypotTriggered;

        /// <summary>
        /// Call this whenever a client uploads/syncs save data to the
        /// server, before trusting any of the other fields in it.
        /// </summary>
        public bool Validate(SaveDataUpload upload)
        {
            if (upload.LegacyBonusTokens == 0)
                return true; // clean

            OnHoneypotTriggered?.Invoke(new Violation
            {
                PlayerId = upload.PlayerId,
                CheckName = "HoneypotTriggered:SaveDataField",
                Severity = ViolationSeverity.Critical,
                Details = $"Save upload had LegacyBonusTokens={upload.LegacyBonusTokens}, legitimate saves never set this field",
                ServerTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
            });

            return false; // reject the whole upload rather than trying to salvage partial data
        }
    }
}
