using System;
using UnityEngine;

namespace NemesisWatch
{
    /// <summary>
    /// The core of Nemesis Watch's server-side authority layer.
    /// Every method here answers one question: "is this physically possible
    /// given what the server itself knows?" The client's claims are never
    /// trusted directly — they're checked against server-owned limits.
    ///
    /// This class does not ban or kick by itself. It only scores and reports
    /// violations through OnViolation, so you plug in your own escalation
    /// policy (log-only, soft-flag for review, auto-kick past a threshold).
    /// </summary>
    public class ServerAuthority
    {
        // Small tolerance so real network jitter and floating point error
        // don't get flagged as cheating.
        private const float SpeedTolerance = 1.15f; // allow 15% over max speed before flagging
        private const float TeleportDistanceThreshold = 15f; // units in one tick — no legit movement causes this

        // Set this to whatever layer(s) your level collision geometry uses
        // (walls, terrain, props) — do NOT include the "Player" layer here,
        // or players will constantly block their own shots against each other.
        public LayerMask LevelGeometryMask = ~0;

        // Rough eye/muzzle height offset above the player's feet position,
        // used as the raycast origin. Replace with the real muzzle transform
        // or head-bone position if your character rig has one — this is a
        // reasonable default for a standing humanoid.
        public float ShooterEyeHeight = 1.6f;

        public event Action<Violation> OnViolation;

        /// <summary>
        /// Call this every server tick for every pending input. Updates
        /// PlayerState.Position only if the movement passes validation;
        /// otherwise the player is snapped back to their last valid position.
        /// </summary>
        public void ValidateAndApplyMovement(PlayerState state, InputCommand input, double serverTime, double deltaTime)
        {
            Vector3 attemptedPosition = state.Position + input.MoveDirection * state.MaxMoveSpeed * (float)deltaTime;
            float distanceThisTick = Vector3.Distance(state.Position, attemptedPosition);
            float maxLegalDistance = state.MaxMoveSpeed * (float)deltaTime * SpeedTolerance;

            if (distanceThisTick > TeleportDistanceThreshold)
            {
                Report(state, "Teleport", ViolationSeverity.Critical,
                    $"Position jumped {distanceThisTick:F1} units in one tick");
                return; // reject outright, keep old position
            }

            if (distanceThisTick > maxLegalDistance)
            {
                Report(state, "SpeedHack", ViolationSeverity.High,
                    $"Moved {distanceThisTick:F2}u, max legal was {maxLegalDistance:F2}u");
                return; // reject this movement, don't apply it
            }

            // Passed validation — this is now the authoritative position.
            state.Position = attemptedPosition;
            state.LastPositionUpdateTime = serverTime;
        }

        /// <summary>
        /// Rate-limits fire events using server-owned timestamps only.
        /// Returns true if the shot is allowed to actually happen.
        /// </summary>
        public bool ValidateFireRequest(PlayerState state, double serverTime)
        {
            double minInterval = 1.0 / state.FireRatePerSecond;
            double elapsed = serverTime - state.LastFireTime;

            if (elapsed < minInterval * 0.85f) // small tolerance for jitter
            {
                Report(state, "FireRate", ViolationSeverity.Medium,
                    $"Fired after {elapsed:F3}s, minimum was {minInterval:F3}s");
                return false;
            }

            state.LastFireTime = serverTime;
            return true;
        }

        public bool ValidateAbilityRequest(PlayerState state, double serverTime)
        {
            double elapsed = serverTime - state.LastAbilityTime;
            if (elapsed < state.AbilityCooldown * 0.9f)
            {
                Report(state, "AbilityCooldown", ViolationSeverity.Medium,
                    $"Used ability after {elapsed:F2}s, cooldown is {state.AbilityCooldown}s");
                return false;
            }

            state.LastAbilityTime = serverTime;
            return true;
        }

        /// <summary>
        /// Validates and applies incoming damage. The server decides the real
        /// damage value from its own weapon table — the client's claimed
        /// damage is only used for the sanity check, never applied directly.
        /// </summary>
        public void ValidateAndApplyDamage(PlayerState attacker, PlayerState victim, float claimedDamage, double serverTime)
        {
            if (claimedDamage > attacker.MaxWeaponDamage * 1.1f)
            {
                Report(attacker, "DamageHack", ViolationSeverity.Critical,
                    $"Claimed {claimedDamage:F1} damage, weapon max is {attacker.MaxWeaponDamage:F1}");
                return; // do not apply — recompute real damage server-side instead
            }

            float realDamage = Math.Min(claimedDamage, attacker.MaxWeaponDamage);
            victim.Health = Math.Max(0, victim.Health - realDamage);
        }

        /// <summary>
        /// Line-of-sight / range sanity check for a claimed hit. Rejects hits
        /// that are out of weapon range, and separately rejects hits where a
        /// wall or other solid geometry sits between shooter and target —
        /// this is what actually catches wallhacks and ESP-assisted
        /// through-wall shots, not just aim assistance.
        /// </summary>
        public bool ValidateHitPlausibility(PlayerState attacker, PlayerState victim, float maxWeaponRange)
        {
            float distance = Vector3.Distance(attacker.Position, victim.Position);
            if (distance > maxWeaponRange * 1.1f)
            {
                Report(attacker, "ImpossibleRangeHit", ViolationSeverity.High,
                    $"Hit registered at {distance:F1}u, weapon range is {maxWeaponRange:F1}u");
                return false;
            }

            Vector3 origin = attacker.Position + Vector3.up * ShooterEyeHeight;
            Vector3 target = victim.Position + Vector3.up * ShooterEyeHeight;
            Vector3 direction = (target - origin).normalized;
            float castDistance = Vector3.Distance(origin, target);

            // A tiny inset stops the ray starting exactly on the victim's own
            // collider surface from immediately "hitting" them at distance ~0.
            const float skin = 0.05f;

            if (Physics.Raycast(origin, direction, out RaycastHit hit, castDistance - skin, LevelGeometryMask))
            {
                // Something solid sits between shooter and target before the
                // claimed hit point is reached — the shot could not have
                // physically landed. This rarely if ever false-positives on
                // legitimate play, so it's treated as a hard rejection.
                Report(attacker, "WallhackHit", ViolationSeverity.Critical,
                    $"Line of sight blocked by '{hit.collider.name}' at {hit.distance:F1}u (claimed hit at {castDistance:F1}u)");
                return false;
            }

            return true;
        }

        private void Report(PlayerState state, string checkName, ViolationSeverity severity, string details)
        {
            state.ViolationScore += (int)severity;

            OnViolation?.Invoke(new Violation
            {
                PlayerId = state.PlayerId,
                CheckName = checkName,
                Severity = severity,
                Details = details,
                ServerTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
            });
        }
    }
}
