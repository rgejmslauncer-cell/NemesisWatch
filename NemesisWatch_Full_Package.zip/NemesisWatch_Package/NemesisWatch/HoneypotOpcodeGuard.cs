using System;

namespace NemesisWatch
{
    /// <summary>
    /// Some cheats work by crafting or replaying network messages directly
    /// rather than touching memory at all — packet manipulation tools that
    /// send the server messages the real client's code never constructs.
    /// A common way they're built: the cheat author sniffs or decompiles
    /// the protocol, finds message types that look "administrative" or
    /// unused, and starts sending them hoping the server accepts them.
    ///
    /// This class defines message types that exist ONLY as bait — the real
    /// client and real server logic never send or expect these in normal
    /// play. Receiving one at all means someone is constructing raw packets
    /// by hand or with a tool, which is a certainty, not a heuristic — there
    /// is no legitimate code path that produces this message. Treat every
    /// hit as Critical and skip straight to a kick, same as a teleport hack.
    /// </summary>
    public enum HoneypotOpcode
    {
        // Named the way a cheat dev skimming your protocol would expect a
        // real admin/debug command to look — that's what makes them get used.
        AdminSetGodMode = 9001,
        AdminGiveAllItems = 9002,
        DebugTeleportAnywhere = 9003,
        DebugUnlockAllWeapons = 9004,
    }

    public class HoneypotOpcodeGuard
    {
        public event Action<Violation> OnHoneypotTriggered;

        /// <summary>
        /// Call this from wherever your server's packet dispatcher decides
        /// it doesn't recognize an opcode as a real gameplay message, before
        /// you'd normally just drop or log it as "unknown packet." Checking
        /// against the honeypot list here means garden-variety protocol
        /// noise (a stale client build, a corrupted packet) gets separated
        /// from someone deliberately trying known-fake privileged commands.
        /// </summary>
        public bool CheckIncomingOpcode(string playerId, int opcodeValue)
        {
            if (!Enum.IsDefined(typeof(HoneypotOpcode), opcodeValue))
                return false; // not one of ours — let normal unknown-packet handling deal with it

            var opcode = (HoneypotOpcode)opcodeValue;

            OnHoneypotTriggered?.Invoke(new Violation
            {
                PlayerId = playerId,
                CheckName = $"HoneypotOpcode:{opcode}",
                Severity = ViolationSeverity.Critical,
                Details = $"Client sent bait opcode {(int)opcode} ({opcode}) — no legitimate client ever constructs this message",
                ServerTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
            });

            return true; // caller should drop the packet and not process it further
        }
    }
}
