using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace NemesisWatch.Client
{
    public class ProcessScanResult
    {
        public bool Clean = true;
        public List<string> FlaggedProcesses = new List<string>();
    }

    /// <summary>
    /// Checks running processes against a blocklist of known cheat/injector
    /// tool names. Be honest with yourself about what this does and doesn't
    /// catch: it stops the laziest tier of cheater (downloaded a public
    /// cheat, never renamed the exe) and nothing more — renaming a file
    /// defeats a name-based check instantly. It's still worth having
    /// because that tier is a real share of your cheating population, but
    /// don't treat a clean scan as proof the client is clean.
    ///
    /// Windows-only by nature of Process enumeration having real teeth
    /// there; on other platforms this becomes a no-op.
    /// </summary>
    public class ProcessScanner
    {
        // Extend this list over time as you see cheats in the wild. Store it
        // server-side and fetch at boot, same reasoning as the hash manifest —
        // a list baked into the client can be edited by anyone who patches
        // the client, so treat it as a fetched, updatable resource.
        private readonly HashSet<string> _blockedProcessNames;

        public ProcessScanner(IEnumerable<string> blockedProcessNames)
        {
            _blockedProcessNames = new HashSet<string>(
                blockedProcessNames.Select(n => n.ToLowerInvariant()));
        }

        public ProcessScanResult Scan()
        {
            var result = new ProcessScanResult();

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            foreach (var process in Process.GetProcesses())
            {
                try
                {
                    string name = process.ProcessName.ToLowerInvariant();
                    if (_blockedProcessNames.Contains(name))
                    {
                        result.Clean = false;
                        result.FlaggedProcesses.Add(process.ProcessName);
                    }
                }
                catch
                {
                    // Some processes throw on access (protected system processes) —
                    // safe to skip, they're not going to be cheat tools.
                }
                finally
                {
                    process.Dispose();
                }
            }
#endif
            // On non-Windows platforms this intentionally returns Clean = true;
            // process-name scanning isn't meaningful there and shouldn't be
            // relied on as a security boundary regardless of platform.

            return result;
        }
    }
}
