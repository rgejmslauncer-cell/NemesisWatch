using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace NemesisWatch.Client
{
    public class ModuleScanResult
    {
        public bool Clean = true;
        public List<string> UnknownModules = new List<string>();
    }

    /// <summary>
    /// Lists every DLL currently loaded into the game's own process and
    /// flags anything that isn't either digitally signed by a trusted
    /// publisher or explicitly whitelisted (your own engine/plugin DLLs,
    /// which may be unsigned in dev builds).
    ///
    /// This catches injected cheat DLLs (the overwhelming majority of
    /// public cheats work this way — inject a DLL, hook rendering/input).
    /// It does NOT catch manual-map injection (a technique that loads code
    /// without it appearing in the normal module list at all) — that needs
    /// memory-region scanning, which is a meaningfully bigger undertaking
    /// and worth adding later once this baseline is in place.
    /// </summary>
    public class ModuleIntegrityMonitor
    {
        private readonly HashSet<string> _whitelistedModuleNames;

        public ModuleIntegrityMonitor(IEnumerable<string> whitelistedModuleNames)
        {
            _whitelistedModuleNames = new HashSet<string>(
                whitelistedModuleNames.Select(n => n.ToLowerInvariant()));
        }

        public ModuleScanResult Scan()
        {
            var result = new ModuleScanResult();

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            var currentProcess = Process.GetCurrentProcess();

            foreach (ProcessModule module in currentProcess.Modules)
            {
                try
                {
                    string name = module.ModuleName.ToLowerInvariant();
                    if (_whitelistedModuleNames.Contains(name))
                        continue;

                    if (IsTrustedSignedModule(module.FileName))
                        continue;

                    result.Clean = false;
                    result.UnknownModules.Add(module.ModuleName);
                }
                catch
                {
                    // A module can unload between enumeration and inspection —
                    // safe to skip, it's not something to act on.
                }
            }
#endif
            return result;
        }

        private static bool IsTrustedSignedModule(string filePath)
        {
            try
            {
                // A valid Authenticode signature from any publisher is treated
                // as trusted here. For tighter control, also check
                // cert.Subject/Issuer against a specific allowed publisher
                // (e.g. Microsoft, NVIDIA, your own signing certificate) —
                // a self-signed or random-publisher cert alone proves much
                // less than a name from a short allowed list.
                using var cert = new X509Certificate2(
                    X509Certificate2.CreateFromSignedFile(filePath));
                return cert.Verify();
            }
            catch
            {
                return false; // unsigned, or signature invalid/tampered
            }
        }
    }
}
