using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace NemesisWatch.Client
{
    [System.Serializable]
    public class RuntimeViolationReport
    {
        public string playerId;
        public string checkName;
        public string details;
        public double clientTimeUtc;
    }

    /// <summary>
    /// Runs module-integrity and hook-detection scans on a randomized
    /// interval throughout the session — deliberately not a fixed timer, so
    /// a cheat can't just patch itself in during the safe window between
    /// checks and patch itself back out right before the next one.
    ///
    /// This component never bans, kicks, or otherwise punishes anyone by
    /// itself. It only reports what it finds to the server, which runs the
    /// finding through the same EscalationPolicy used for gameplay
    /// violations. Client-side self-punishment is trivial to patch out —
    /// the client is attacker-controlled territory, so the only decision
    /// that actually matters is the one the server makes.
    /// </summary>
    public class RuntimeGuard : MonoBehaviour
    {
        public string reportEndpointUrl = "https://your-backend.example.com/nemesis-watch/report";
        public string playerId;

        public float minCheckIntervalSeconds = 20f;
        public float maxCheckIntervalSeconds = 55f;

        private ModuleIntegrityMonitor _moduleMonitor;
        private HookDetector _hookDetector;

        private void Start()
        {
            _moduleMonitor = new ModuleIntegrityMonitor(new[]
            {
                "unityplayer.dll", "gameassembly.dll", "d3d11.dll", "d3d12.dll",
                "opengl32.dll", "vulkan-1.dll"
                // Add every DLL your own build legitimately ships/loads here —
                // this list intentionally starts small; grow it as you find
                // false positives during your own testing, not guesswork.
            });

            _hookDetector = new HookDetector(new List<(string, string)>
            {
                ("user32.dll", "GetAsyncKeyState"),  // common input-sniffing hook target
                ("user32.dll", "GetCursorPos"),
                ("dxgi.dll", "Present"),              // classic overlay/ESP hook point
            });

            StartCoroutine(RunLoop());
        }

        private IEnumerator RunLoop()
        {
            while (true)
            {
                float wait = Random.Range(minCheckIntervalSeconds, maxCheckIntervalSeconds);
                yield return new WaitForSeconds(wait);

                var moduleResult = _moduleMonitor.Scan();
                if (!moduleResult.Clean)
                {
                    foreach (var module in moduleResult.UnknownModules)
                        yield return Report("UnsignedModuleLoaded", module);
                }

                var hookResult = _hookDetector.Scan();
                if (!hookResult.Clean)
                {
                    foreach (var hook in hookResult.HookedFunctions)
                        yield return Report("FunctionHookDetected", hook);
                }
            }
        }

        private IEnumerator Report(string checkName, string details)
        {
            var report = new RuntimeViolationReport
            {
                playerId = playerId,
                checkName = checkName,
                details = details,
                clientTimeUtc = System.DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
            };

            string json = JsonUtility.ToJson(report);
            using var request = new UnityWebRequest(reportEndpointUrl, "POST");
            byte[] body = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(body);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            // Sign or authenticate this request the same way you authenticate
            // the player's normal game traffic — an unauthenticated report
            // endpoint is itself something a cheat could spam with garbage
            // to bury real reports.

            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
                Debug.LogWarning($"[NemesisWatch] Failed to send report: {request.error}");
        }
    }
}
