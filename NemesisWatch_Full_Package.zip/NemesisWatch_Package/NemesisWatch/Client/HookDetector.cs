using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace NemesisWatch.Client
{
    public class HookScanResult
    {
        public bool Clean = true;
        public List<string> HookedFunctions = new List<string>();
    }

    /// <summary>
    /// Detects inline API hooks — the technique most overlay/ESP cheats use
    /// to intercept calls like DirectX's Present/EndScene or input functions
    /// so they can draw on top of the game or read input before it arrives.
    ///
    /// How it works: an unhooked function's first bytes are normal compiled
    /// code belonging to its own module. A hook typically overwrites those
    /// first bytes with a jump (0xE9 = near jmp, or 0xFF 0x25 = jmp through
    /// a pointer) redirecting execution into the hooking DLL. So: read the
    /// first few bytes, and if they form a jump, resolve where it actually
    /// goes — if that destination falls outside the function's own module,
    /// something has hooked it.
    ///
    /// Caveats, stated plainly: legitimate software (some overlays like
    /// Discord/GeForce Experience, some anti-virus) also hooks these same
    /// functions, so a hit here is a signal to investigate/flag, not an
    /// automatic ban. And a sufficiently careful cheat can hide from this
    /// specific technique (hooking further down the call chain, or using
    /// hardware breakpoints instead of inline patches) — this closes the
    /// common case, not every case.
    /// </summary>
    public class HookDetector
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        private static extern IntPtr GetModuleHandle(string moduleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

        /// <summary>
        /// (module name, function name) pairs worth watching. Start with the
        /// functions cheats actually target for your game — DirectX/OpenGL
        /// present calls for overlays, plus any WinAPI calls your own
        /// anti-cheat relies on elsewhere (hooking those specifically to
        /// blind your own checks is a known counter-move worth watching for).
        /// </summary>
        private readonly List<(string module, string function)> _watchedFunctions;

        public HookDetector(List<(string module, string function)> watchedFunctions)
        {
            _watchedFunctions = watchedFunctions;
        }

        public HookScanResult Scan()
        {
            var result = new HookScanResult();

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            foreach (var (moduleName, functionName) in _watchedFunctions)
            {
                IntPtr moduleHandle = GetModuleHandle(moduleName);
                if (moduleHandle == IntPtr.Zero) continue; // module not loaded, nothing to check

                IntPtr functionAddress = GetProcAddress(moduleHandle, functionName);
                if (functionAddress == IntPtr.Zero) continue;

                if (LooksHooked(functionAddress, moduleName, functionName, out string details))
                {
                    result.Clean = false;
                    result.HookedFunctions.Add($"{moduleName}!{functionName} ({details})");
                }
            }
#endif
            return result;
        }

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
        private bool LooksHooked(IntPtr functionAddress, string moduleName, string functionName, out string details)
        {
            details = "";
            byte[] prologue = new byte[8];
            Marshal.Copy(functionAddress, prologue, 0, prologue.Length);

            IntPtr jumpTarget = IntPtr.Zero;

            if (prologue[0] == 0xE9)
            {
                // Near relative jump: target = next instruction address + displacement
                int displacement = BitConverter.ToInt32(prologue, 1);
                jumpTarget = IntPtr.Add(functionAddress, 5 + displacement);
            }
            else if (prologue[0] == 0xFF && prologue[1] == 0x25)
            {
                // jmp qword ptr [rip+disp32] — the pointer itself must be
                // dereferenced to get the real target.
                int displacement = BitConverter.ToInt32(prologue, 2);
                IntPtr pointerLocation = IntPtr.Add(functionAddress, 6 + displacement);
                jumpTarget = Marshal.ReadIntPtr(pointerLocation);
            }
            else
            {
                return false; // no jump-style prologue detected, looks like normal compiled code
            }

            if (!IsAddressInsideModule(jumpTarget, moduleName))
            {
                details = $"redirects outside {moduleName}";
                return true;
            }

            return false;
        }

        private bool IsAddressInsideModule(IntPtr address, string moduleName)
        {
            foreach (ProcessModule module in Process.GetCurrentProcess().Modules)
            {
                if (!string.Equals(module.ModuleName, moduleName, StringComparison.OrdinalIgnoreCase))
                    continue;

                long start = module.BaseAddress.ToInt64();
                long end = start + module.ModuleMemorySize;
                long target = address.ToInt64();
                return target >= start && target < end;
            }
            return false; // couldn't find the module at all, treat as suspicious by default
        }
#endif
    }
}
