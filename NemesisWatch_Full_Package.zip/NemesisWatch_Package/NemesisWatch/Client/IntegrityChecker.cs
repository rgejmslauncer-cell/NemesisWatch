using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;

namespace NemesisWatch.Client
{
    public class IntegrityResult
    {
        public bool Passed;
        public List<string> MismatchedFiles = new List<string>();
        public List<string> MissingFiles = new List<string>();
    }

    /// <summary>
    /// Hashes the files that matter (main executable, core assemblies,
    /// anything a patcher would touch) and compares them against a manifest
    /// of known-good hashes.
    ///
    /// IMPORTANT: never ship the expected hashes only as a local file next
    /// to the game — a patcher can edit both the binary and the hash list
    /// in the same pass. Fetch the manifest from your server at boot time
    /// (see FetchManifestFromServer below) so tampering the local install
    /// alone can't fool the check. The local manifest here exists only as
    /// an offline fallback for when the server is briefly unreachable.
    /// </summary>
    public class IntegrityChecker
    {
        private readonly Dictionary<string, string> _expectedHashes; // relative path -> lowercase hex SHA-256
        private readonly string _installRoot;

        public IntegrityChecker(string installRoot, Dictionary<string, string> expectedHashes)
        {
            _installRoot = installRoot;
            _expectedHashes = expectedHashes;
        }

        public IntegrityResult CheckAll()
        {
            var result = new IntegrityResult { Passed = true };

            foreach (var entry in _expectedHashes)
            {
                string fullPath = Path.Combine(_installRoot, entry.Key);

                if (!File.Exists(fullPath))
                {
                    result.MissingFiles.Add(entry.Key);
                    result.Passed = false;
                    continue;
                }

                string actualHash = ComputeSha256(fullPath);
                if (!string.Equals(actualHash, entry.Value, StringComparison.OrdinalIgnoreCase))
                {
                    result.MismatchedFiles.Add(entry.Key);
                    result.Passed = false;
                }
            }

            return result;
        }

        public static string ComputeSha256(string filePath)
        {
            using var sha256 = SHA256.Create();
            using var stream = File.OpenRead(filePath);
            byte[] hash = sha256.ComputeHash(stream);
            return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
        }

        /// <summary>
        /// Builds a manifest from the files currently on disk. Run this
        /// once on your build server right after producing a release build,
        /// then upload the resulting JSON to wherever your client fetches
        /// the manifest from — never generate this on a player's machine.
        /// </summary>
        public static Dictionary<string, string> BuildManifest(string buildRoot, IEnumerable<string> relativePaths)
        {
            var manifest = new Dictionary<string, string>();
            foreach (var relativePath in relativePaths)
            {
                string fullPath = Path.Combine(buildRoot, relativePath);
                manifest[relativePath] = ComputeSha256(fullPath);
            }
            return manifest;
        }
    }
}
