using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace NemesisWatch.Client
{
    /// <summary>
    /// Put this on a bootstrap scene that loads first, before your main menu.
    /// It runs the pre-launch checks in sequence, drives the same splash UI
    /// we mocked up earlier (status text + progress bar), and only allows
    /// the player through to the main menu if everything passes.
    ///
    /// Wire statusText / progressBar / okButton to the actual UI elements
    /// in your bootstrap scene.
    /// </summary>
    public class BootGate : MonoBehaviour
    {
        [Header("UI (match the splash mockup)")]
        public Text statusText;
        public Slider progressBar;
        public Button okButton;

        [Header("Config")]
        public string manifestUrl = "https://your-backend.example.com/nemesis-watch/manifest.json";
        public string blockedProcessListUrl = "https://your-backend.example.com/nemesis-watch/blocked-processes.json";
        public string mainMenuSceneName = "MainMenu";

        private void Start()
        {
            okButton.interactable = false;
            okButton.onClick.AddListener(() => SceneManager.LoadScene(mainMenuSceneName));
            StartCoroutine(RunBootSequence());
        }

        private IEnumerator RunBootSequence()
        {
            SetStep("Starting up…", 0f);
            yield return new WaitForSeconds(0.3f); // let the window actually paint before the first heavy step

            // Step 1 — fetch the current manifest + blocklist from the server.
            // Doing this before the file check is what stops a patched client
            // from also shipping a patched local manifest to match itself.
            SetStep("Contacting Nemesis Watch server…", 0.15f);
            Dictionary<string, string> manifest = null;
            List<string> blockedProcesses = null;
            yield return FetchJson<Dictionary<string, string>>(manifestUrl, r => manifest = r);
            yield return FetchJson<List<string>>(blockedProcessListUrl, r => blockedProcesses = r);

            if (manifest == null || blockedProcesses == null)
            {
                Fail("Couldn't reach the Nemesis Watch server. Check your connection and try again.");
                yield break;
            }

            // Step 2 — integrity check
            SetStep("Checking game file integrity…", 0.4f);
            var integrityChecker = new IntegrityChecker(Application.dataPath, manifest);
            var integrityResult = integrityChecker.CheckAll();
            if (!integrityResult.Passed)
            {
                Fail("Game files appear to have been modified. Please verify/reinstall the game.");
                yield break;
            }

            // Step 3 — process scan
            SetStep("Scanning running processes…", 0.6f);
            var processScanner = new ProcessScanner(blockedProcesses);
            var processResult = processScanner.Scan();
            if (!processResult.Clean)
            {
                Fail("Please close the following programs before launching: " +
                     string.Join(", ", processResult.FlaggedProcesses));
                yield break;
            }

            // Step 4 — environment check
            SetStep("Verifying environment…", 0.8f);
            var environmentChecker = new EnvironmentChecker();
            var environmentResult = environmentChecker.Check();
            if (!environmentResult.Clean)
            {
                Fail("A debugger was detected. Please close it and relaunch the game.");
                yield break;
            }

            // All clear
            SetStep("All checks passed", 1f);
            okButton.interactable = true;
        }

        private IEnumerator FetchJson<T>(string url, System.Action<T> onSuccess)
        {
            using var request = UnityWebRequest.Get(url);
            request.timeout = 8;
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogWarning($"[NemesisWatch] Failed to fetch {url}: {request.error}");
                yield break;
            }

            var parsed = JsonUtility.FromJson<T>(request.downloadHandler.text);
            onSuccess(parsed);
            // Note: JsonUtility doesn't handle raw Dictionary/List well in every
            // Unity version — swap in Newtonsoft.Json (com.unity.nuget.newtonsoft-json)
            // if you hit serialization issues with these shapes.
        }

        private void SetStep(string label, float progress)
        {
            statusText.text = label;
            progressBar.value = progress;
        }

        private void Fail(string reason)
        {
            statusText.text = reason;
            progressBar.value = 0f;
            okButton.interactable = false;
            // Decide your own policy here: fully block launch (recommended for
            // integrity/process failures) vs. allow but flag server-side for
            // review (better for environment checks, which are easier to
            // false-positive on legitimate dev tools).
        }
    }
}
