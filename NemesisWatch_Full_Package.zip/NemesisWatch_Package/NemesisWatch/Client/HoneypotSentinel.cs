using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace NemesisWatch.Client
{
    /// <summary>
    /// Plants decoy values in memory that look like tempting cheat targets
    /// (god mode, infinite ammo, currency) but are never read or written by
    /// any real game logic. A memory-scanning cheat tool (Cheat Engine and
    /// its many derivatives) can't tell the difference between a real
    /// gameplay variable and one of these just by looking at memory — it
    /// finds a plausible-looking value, changes it, and the change alone is
    /// the tell. There is essentially no way for a legitimate player to
    /// trigger this by accident, which is what makes a honeypot hit far
    /// more trustworthy than any heuristic check.
    ///
    /// Naming matters here: name these fields the way a cheat's memory
    /// scanner or a public "Cheat Engine table" would expect a real one to
    /// be named/structured, so it actually gets bitten. A field literally
    /// called "HoneypotDoNotTouch" won't attract anything.
    /// </summary>
    public class HoneypotSentinel : MonoBehaviour
    {
        public string reportEndpointUrl = "https://your-backend.example.com/nemesis-watch/report";
        public string playerId;

        // Looks like a real god-mode flag. No code anywhere reads this to
        // actually grant invincibility — the server is what decides damage,
        // as established back in ServerAuthority.
        [SerializeField] private int _godModeEnabled = 0;

        // Looks like a real ammo count. Real ammo is tracked elsewhere and
        // synced with the server; this copy exists purely as bait.
        [SerializeField] private int _infiniteAmmoFlag = 0;

        // Looks like a real currency balance. The actual balance lives
        // server-side and is never trusted from the client at all — this
        // local copy is bait for save/memory editors specifically.
        [SerializeField] private int _localCoinBalance = 0;

        private int _expectedGodMode;
        private int _expectedAmmoFlag;
        private int _expectedCoinBalance;

        public float minCheckIntervalSeconds = 15f;
        public float maxCheckIntervalSeconds = 40f;

        private void Start()
        {
            // Snapshot the values we ourselves set, so any later mismatch
            // can only have come from something external poking the memory.
            _expectedGodMode = _godModeEnabled;
            _expectedAmmoFlag = _infiniteAmmoFlag;
            _expectedCoinBalance = _localCoinBalance;

            StartCoroutine(WatchLoop());
        }

        private IEnumerator WatchLoop()
        {
            while (true)
            {
                float wait = Random.Range(minCheckIntervalSeconds, maxCheckIntervalSeconds);
                yield return new WaitForSeconds(wait);

                if (_godModeEnabled != _expectedGodMode)
                {
                    yield return Report("HoneypotTriggered:GodModeFlag",
                        $"value changed from {_expectedGodMode} to {_godModeEnabled} outside game logic");
                    _expectedGodMode = _godModeEnabled; // avoid re-reporting the same change every check
                }

                if (_infiniteAmmoFlag != _expectedAmmoFlag)
                {
                    yield return Report("HoneypotTriggered:AmmoFlag",
                        $"value changed from {_expectedAmmoFlag} to {_infiniteAmmoFlag} outside game logic");
                    _expectedAmmoFlag = _infiniteAmmoFlag;
                }

                if (_localCoinBalance != _expectedCoinBalance)
                {
                    yield return Report("HoneypotTriggered:CoinBalance",
                        $"value changed from {_expectedCoinBalance} to {_localCoinBalance} outside game logic");
                    _expectedCoinBalance = _localCoinBalance;
                }
            }
        }

        private IEnumerator Report(string checkName, string details)
        {
            var report = new RuntimeViolationReport
            {
                playerId = playerId,
                checkName = checkName,
                details = details,
                clientTimeUtc = System.DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0
            };

            string json = JsonUtility.ToJson(report);
            using var request = new UnityWebRequest(reportEndpointUrl, "POST");
            byte[] body = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(body);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
                Debug.LogWarning($"[NemesisWatch] Failed to send honeypot report: {request.error}");
        }
    }
}
