using System.Diagnostics;
using System.Runtime.InteropServices;

namespace NemesisWatch.Client
{
    public class EnvironmentResult
    {
        public bool Clean = true;
        public bool ManagedDebuggerAttached;
        public bool NativeDebuggerPresent;
    }

    /// <summary>
    /// Cheap, honest checks for a debugger attached to the process at boot
    /// time. These are trivially bypassed by anyone who specifically wants
    /// to bypass them — a real anti-debug arms race needs the layered,
    /// constantly-updated techniques a dedicated system like EAC/BattlEye
    /// runs. What this DOES catch: the debugger being open before launch,
    /// which covers a surprising number of people using off-the-shelf
    /// trainers/memory editors who never bothered to hide it.
    /// </summary>
    public class EnvironmentChecker
    {
        [DllImport("kernel32.dll")]
        private static extern bool IsDebuggerPresent();

        public EnvironmentResult Check()
        {
            var result = new EnvironmentResult();

            result.ManagedDebuggerAttached = Debugger.IsAttached;

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            result.NativeDebuggerPresent = IsDebuggerPresent();
#endif

            result.Clean = !result.ManagedDebuggerAttached && !result.NativeDebuggerPresent;
            return result;
        }
    }
}
