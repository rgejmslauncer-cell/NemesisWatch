namespace NemesisWatch
{
    public enum ViolationSeverity { Low = 1, Medium = 5, High = 20, Critical = 100 }

    public class Violation
    {
        public string PlayerId;
        public string CheckName;
        public ViolationSeverity Severity;
        public string Details;
        public double ServerTime;
    }
}
