using System;
using System.Collections.Generic;

namespace NemesisWatch
{
    public enum EscalationAction { None, LogOnly, FlagForReview, Kick, Ban }

    /// <summary>
    /// Decides what to do once violations start piling up for a player.
    /// Deliberately conservative by default: low-severity noise (network
    /// jitter, one-off false positives) never triggers punishment on its
    /// own. Only sustained or severe violations escalate.
    ///
    /// Scores DECAY over time (exponential half-life) rather than
    /// accumulating forever. This matters more than it looks: without
    /// decay, a single old Critical hit — even a false positive — leaves a
    /// player permanently flagged for the rest of their time with your
    /// game, since nothing they do afterward can bring the score back down.
    /// With decay, a player who reforms (or was wrongly flagged once) sees
    /// their score fade back toward zero over the configured half-life.
    ///
    /// A single Critical violation still triggers an immediate Kick
    /// regardless of decay or history — teleports, impossible damage, and
    /// similar checks essentially never false-positive on legitimate play,
    /// so there's no reason to wait for a pattern before acting on one.
    ///
    /// Tune the thresholds and half-life once you have real data from your
    /// playerbase — these starting numbers are a reasonable first guess,
    /// not gospel.
    /// </summary>
    public class EscalationPolicy
    {
        private class PlayerScoreState
        {
            public double CurrentScore;
            public double LastUpdateServerTime;
        }

        private readonly Dictionary<string, PlayerScoreState> _scores = new();
        private readonly Dictionary<string, List<Violation>> _history = new();

        public int FlagThreshold = 30;   // score at which a human should review the player
        public int KickThreshold = 80;   // score at which the player is disconnected
        public int BanThreshold = 150;   // score at which the account is banned

        // How long it takes accumulated score to fall to half its value with
        // no further violations. 24 hours is a reasonable starting point —
        // long enough that a cheater can't just wait out a short cooldown
        // between matches, short enough that a single old flag doesn't
        // follow an otherwise-clean player forever.
        public double DecayHalfLifeHours = 24.0;

        public EscalationAction Evaluate(Violation violation)
        {
            if (!_history.TryGetValue(violation.PlayerId, out var list))
            {
                list = new List<Violation>();
                _history[violation.PlayerId] = list;
            }
            list.Add(violation);

            double totalScore = ApplyDecayAndAdd(violation);

            // A single Critical hit (teleport, impossible damage) skips straight
            // to a kick even if it's the player's first ever flag — these checks
            // essentially never false-positive on legitimate play.
            if (violation.Severity == ViolationSeverity.Critical)
                return EscalationAction.Kick;

            if (totalScore >= BanThreshold) return EscalationAction.Ban;
            if (totalScore >= KickThreshold) return EscalationAction.Kick;
            if (totalScore >= FlagThreshold) return EscalationAction.FlagForReview;
            return EscalationAction.LogOnly;
        }

        private double ApplyDecayAndAdd(Violation violation)
        {
            if (!_scores.TryGetValue(violation.PlayerId, out var state))
            {
                state = new PlayerScoreState { CurrentScore = 0, LastUpdateServerTime = violation.ServerTime };
                _scores[violation.PlayerId] = state;
            }

            double elapsedSeconds = violation.ServerTime - state.LastUpdateServerTime;
            if (elapsedSeconds > 0 && DecayHalfLifeHours > 0)
            {
                double halfLifeSeconds = DecayHalfLifeHours * 3600.0;
                double decayFactor = Math.Pow(0.5, elapsedSeconds / halfLifeSeconds);
                state.CurrentScore *= decayFactor;
            }

            state.CurrentScore += (int)violation.Severity;
            state.LastUpdateServerTime = violation.ServerTime;

            return state.CurrentScore;
        }

        /// <summary>
        /// Current decayed score for a player without recording a new
        /// violation — useful for a dashboard showing "risk level" live.
        /// </summary>
        public double GetCurrentScore(string playerId, double asOfServerTime)
        {
            if (!_scores.TryGetValue(playerId, out var state))
                return 0;

            double elapsedSeconds = asOfServerTime - state.LastUpdateServerTime;
            if (elapsedSeconds <= 0 || DecayHalfLifeHours <= 0)
                return state.CurrentScore;

            double halfLifeSeconds = DecayHalfLifeHours * 3600.0;
            return state.CurrentScore * Math.Pow(0.5, elapsedSeconds / halfLifeSeconds);
        }

        public IReadOnlyList<Violation> GetHistory(string playerId) =>
            _history.TryGetValue(playerId, out var list) ? list : Array.Empty<Violation>();
    }
}
