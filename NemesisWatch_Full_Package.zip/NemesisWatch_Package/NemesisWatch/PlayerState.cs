using System;
using UnityEngine;

namespace NemesisWatch
{
    /// <summary>
    /// Authoritative state for one player, owned entirely by the server.
    /// The client never gets to overwrite these values directly — it only
    /// sends inputs, and the server decides what actually happens.
    /// </summary>
    public class PlayerState
    {
        public string PlayerId;

        // The actual Unity GameObject/Collider for this player on the headless
        // server, used to exclude self-hits when raycasting for wallhacks.
        public GameObject PlayerObject;

        public Vector3 Position;
        public Vector3 Velocity;
        public float Health = 100f;
        public float MaxHealth = 100f;

        // Timestamps used for rate limiting (seconds, server clock)
        public double LastFireTime = -999;
        public double LastAbilityTime = -999;
        public double LastPositionUpdateTime;

        // Weapon/ability config the server trusts (never read this from the client)
        public float FireRatePerSecond = 8f;      // max shots/sec for the equipped weapon
        public float AbilityCooldown = 3f;        // seconds
        public float MaxMoveSpeed = 7f;            // units/sec, sprint included
        public float MaxWeaponDamage = 35f;        // highest legal single hit for current loadout

        public int ViolationScore = 0;
    }

    /// <summary>
    /// What the client actually sends each tick/frame — intent only, never results.
    /// </summary>
    public struct InputCommand
    {
        public string PlayerId;
        public double ClientTimestamp;   // for lag-compensation, not trusted for timing decisions
        public Vector3 MoveDirection;    // normalized direction, client-provided
        public bool WantsToFire;
        public bool WantsToUseAbility;
        public bool HasClaimedHit;
        public Vector3 ClaimedHitPosition; // where the client claims a hit landed, for reconciliation
    }
}
