using NUnit.Framework;
using NemesisWatch;

namespace NemesisWatch.Tests
{
    public class HoneypotTests
    {
        [Test]
        public void BaitOpcode_TriggersCriticalViolation()
        {
            var guard = new HoneypotOpcodeGuard();
            Violation captured = null;
            guard.OnHoneypotTriggered += v => captured = v;

            bool wasHoneypot = guard.CheckIncomingOpcode("cheaterPlayer", (int)HoneypotOpcode.AdminSetGodMode);

            Assert.IsTrue(wasHoneypot);
            Assert.IsNotNull(captured);
            Assert.AreEqual(ViolationSeverity.Critical, captured.Severity);
        }

        [Test]
        public void UnknownNonBaitOpcode_DoesNotTrigger()
        {
            var guard = new HoneypotOpcodeGuard();
            bool triggered = false;
            guard.OnHoneypotTriggered += _ => triggered = true;

            // Some arbitrary opcode value that isn't one of ours.
            bool wasHoneypot = guard.CheckIncomingOpcode("normalPlayer", 42);

            Assert.IsFalse(wasHoneypot);
            Assert.IsFalse(triggered);
        }

        [Test]
        public void CleanSaveData_PassesValidation()
        {
            var honeypot = new SaveDataHoneypot();
            var upload = new SaveDataUpload { PlayerId = "player1", Coins = 500, Level = 12, LegacyBonusTokens = 0 };

            bool result = honeypot.Validate(upload);

            Assert.IsTrue(result);
        }

        [Test]
        public void TamperedSaveData_IsRejected()
        {
            var honeypot = new SaveDataHoneypot();
            Violation captured = null;
            honeypot.OnHoneypotTriggered += v => captured = v;

            var upload = new SaveDataUpload { PlayerId = "cheaterPlayer", Coins = 999999, Level = 99, LegacyBonusTokens = 500 };

            bool result = honeypot.Validate(upload);

            Assert.IsFalse(result);
            Assert.IsNotNull(captured);
            Assert.AreEqual(ViolationSeverity.Critical, captured.Severity);
        }
    }
}
