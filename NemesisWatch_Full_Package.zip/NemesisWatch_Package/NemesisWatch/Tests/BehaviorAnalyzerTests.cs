using NUnit.Framework;
using NemesisWatch;
using NemesisWatch.Behavioral;

namespace NemesisWatch.Tests
{
    public class BehaviorAnalyzerTests
    {
        [Test]
        public void FewSamples_NeverFlags_EvenIfExtreme()
        {
            var analyzer = new BehaviorAnalyzer();
            bool flagged = false;
            analyzer.OnBehavioralFlag += _ => flagged = true;

            // Fewer than RollingStat's minimum sample count (20) — should
            // never flag, no matter how extreme the values are.
            for (int i = 0; i < 5; i++)
                analyzer.RecordReactionTime("player1", 10); // inhumanly fast

            Assert.IsFalse(flagged, "Should not flag before enough samples exist to mean anything.");
        }

        [Test]
        public void SustainedFastReactionTime_EventuallyFlags()
        {
            var analyzer = new BehaviorAnalyzer();
            bool flagged = false;
            analyzer.OnBehavioralFlag += _ => flagged = true;

            // Build a normal-looking population baseline first (~200ms reactions).
            var rand = new System.Random(42);
            for (int i = 0; i < 50; i++)
                analyzer.RecordReactionTime("normalPlayer", 180 + rand.Next(-30, 30));

            // Now one player reacts inhumanly fast, repeatedly.
            for (int i = 0; i < 15 && !flagged; i++)
                analyzer.RecordReactionTime("suspiciousPlayer", 15);

            Assert.IsTrue(flagged, "Sustained, extreme reaction times should eventually flag.");
        }

        [Test]
        public void OccasionalFastFlick_WithoutHit_DoesNotFlagAimSnap()
        {
            var analyzer = new BehaviorAnalyzer();
            bool flagged = false;
            analyzer.OnBehavioralFlag += _ => flagged = true;

            var rand = new System.Random(1);
            for (int i = 0; i < 50; i++)
                analyzer.RecordAimSnap("player1", 5 + rand.NextDouble() * 5, followedByHit: false);

            // A few big snaps that MISS shouldn't count as aimbot behavior.
            for (int i = 0; i < 10; i++)
                analyzer.RecordAimSnap("player1", 80, followedByHit: false);

            Assert.IsFalse(flagged, "A snap without a landing hit should not be treated as suspicious.");
        }

        [Test]
        public void RepeatedLargeSnapsThatAlwaysHit_Flags()
        {
            var analyzer = new BehaviorAnalyzer();
            bool flagged = false;
            analyzer.OnBehavioralFlag += _ => flagged = true;

            var rand = new System.Random(2);
            for (int i = 0; i < 50; i++)
                analyzer.RecordAimSnap("baseline", 5 + rand.NextDouble() * 5, followedByHit: false);

            for (int i = 0; i < 10 && !flagged; i++)
                analyzer.RecordAimSnap("suspiciousPlayer", 90, followedByHit: true);

            Assert.IsTrue(flagged, "Large snaps that consistently land should flag as aimbot-like.");
        }
    }
}
