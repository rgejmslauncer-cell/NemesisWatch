using NUnit.Framework;
using NemesisWatch;

namespace NemesisWatch.Tests
{
    public class EscalationPolicyTests
    {
        [Test]
        public void CriticalViolation_AlwaysTriggersKick()
        {
            var policy = new EscalationPolicy();
            var violation = new Violation
            {
                PlayerId = "player1",
                CheckName = "Teleport",
                Severity = ViolationSeverity.Critical,
                Details = "test"
            };

            var action = policy.Evaluate(violation);

            Assert.AreEqual(EscalationAction.Kick, action);
        }

        [Test]
        public void SingleLowSeverityViolation_DoesNotEscalate()
        {
            var policy = new EscalationPolicy();
            var violation = new Violation
            {
                PlayerId = "player2",
                CheckName = "FireRate",
                Severity = ViolationSeverity.Low,
                Details = "test"
            };

            var action = policy.Evaluate(violation);

            Assert.AreEqual(EscalationAction.LogOnly, action);
        }

        [Test]
        public void AccumulatedMediumViolations_ReachFlagThreshold()
        {
            var policy = new EscalationPolicy { FlagThreshold = 20 };
            var playerId = "player3";
            EscalationAction lastAction = EscalationAction.None;

            // Medium = 5 points each. 5 of them should cross a threshold of 20.
            for (int i = 0; i < 5; i++)
            {
                lastAction = policy.Evaluate(new Violation
                {
                    PlayerId = playerId,
                    CheckName = "FireRate",
                    Severity = ViolationSeverity.Medium,
                    Details = $"violation {i}"
                });
            }

            Assert.AreEqual(EscalationAction.FlagForReview, lastAction);
        }

        [Test]
        public void ViolationsFromDifferentPlayers_AreScoredIndependently()
        {
            var policy = new EscalationPolicy { FlagThreshold = 20 };

            policy.Evaluate(new Violation { PlayerId = "playerA", Severity = ViolationSeverity.Medium, CheckName = "x" });
            var actionForB = policy.Evaluate(new Violation { PlayerId = "playerB", Severity = ViolationSeverity.Low, CheckName = "x" });

            // playerB's single low-severity hit shouldn't be affected by playerA's history.
            Assert.AreEqual(EscalationAction.LogOnly, actionForB);
        }

        [Test]
        public void OldViolations_DecayBackDown_OverSimulatedTime()
        {
            var policy = new EscalationPolicy { FlagThreshold = 20, DecayHalfLifeHours = 1.0 };
            var playerId = "decayTestPlayer";

            // Rack up score right away (all at the same simulated timestamp).
            for (int i = 0; i < 5; i++)
            {
                policy.Evaluate(new Violation
                {
                    PlayerId = playerId,
                    Severity = ViolationSeverity.Medium,
                    CheckName = "x",
                    ServerTime = 1000.0
                });
            }

            double scoreRightAfter = policy.GetCurrentScore(playerId, asOfServerTime: 1000.0);
            Assert.Greater(scoreRightAfter, 20, "Sanity check: score should be well above threshold right after accumulating.");

            // Ask for the score 2 full half-lives later (2 hours = 7200s),
            // with no further violations in between.
            double scoreMuchLater = policy.GetCurrentScore(playerId, asOfServerTime: 1000.0 + 7200.0);

            Assert.Less(scoreMuchLater, scoreRightAfter / 3.0,
                "Score should have decayed to roughly a quarter of its value after two half-lives.");
        }
    }
}
