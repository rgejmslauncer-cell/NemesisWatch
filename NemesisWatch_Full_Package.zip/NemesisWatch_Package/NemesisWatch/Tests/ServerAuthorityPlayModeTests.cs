using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using NemesisWatch;

namespace NemesisWatch.Tests
{
    /// <summary>
    /// These tests need real Physics.Raycast against real colliders, so they
    /// run in Play Mode (Test Runner → PlayMode tab), not Edit Mode. Each
    /// test builds and tears down its own tiny scene.
    /// </summary>
    public class ServerAuthorityPlayModeTests
    {
        [UnityTest]
        public IEnumerator Teleport_IsRejected()
        {
            var authority = new ServerAuthority();
            var state = new PlayerState { PlayerId = "p1", Position = Vector3.zero, MaxMoveSpeed = 5f };
            bool violationFired = false;
            authority.OnViolation += v => { if (v.CheckName == "Teleport") violationFired = true; };

            var input = new InputCommand { MoveDirection = Vector3.forward * 1000 }; // absurd distance
            authority.ValidateAndApplyMovement(state, input, serverTime: 1.0, deltaTime: 0.02);

            Assert.IsTrue(violationFired);
            Assert.AreEqual(Vector3.zero, state.Position, "Position should not have moved.");
            yield return null;
        }

        [UnityTest]
        public IEnumerator NormalMovement_IsAccepted()
        {
            var authority = new ServerAuthority();
            var state = new PlayerState { PlayerId = "p1", Position = Vector3.zero, MaxMoveSpeed = 5f };

            var input = new InputCommand { MoveDirection = Vector3.forward };
            authority.ValidateAndApplyMovement(state, input, serverTime: 1.0, deltaTime: 0.02); // 5 * 0.02 = 0.1 units, legal

            Assert.Greater(state.Position.z, 0f);
            yield return null;
        }

        [UnityTest]
        public IEnumerator FireRate_RejectsRapidRepeatedShots()
        {
            var authority = new ServerAuthority();
            var state = new PlayerState { PlayerId = "p1", FireRatePerSecond = 5f }; // min interval 0.2s

            bool first = authority.ValidateFireRequest(state, serverTime: 1.000);
            bool second = authority.ValidateFireRequest(state, serverTime: 1.010); // only 10ms later — illegal

            Assert.IsTrue(first);
            Assert.IsFalse(second);
            yield return null;
        }

        [UnityTest]
        public IEnumerator HitThroughWall_IsRejected()
        {
            // Build a wall collider directly between attacker and victim.
            var wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            wall.transform.position = new Vector3(0, 0, 5);
            wall.transform.localScale = new Vector3(10, 10, 1);

            yield return null; // let physics register the new collider

            var authority = new ServerAuthority();
            var attacker = new PlayerState { PlayerId = "attacker", Position = new Vector3(0, 0, 0) };
            var victim = new PlayerState { PlayerId = "victim", Position = new Vector3(0, 0, 10) };

            bool violationFired = false;
            authority.OnViolation += v => { if (v.CheckName == "WallhackHit") violationFired = true; };

            bool result = authority.ValidateHitPlausibility(attacker, victim, maxWeaponRange: 50f);

            Assert.IsFalse(result);
            Assert.IsTrue(violationFired);

            Object.Destroy(wall);
        }

        [UnityTest]
        public IEnumerator HitWithClearLineOfSight_IsAccepted()
        {
            var authority = new ServerAuthority();
            var attacker = new PlayerState { PlayerId = "attacker", Position = new Vector3(0, 0, 0) };
            var victim = new PlayerState { PlayerId = "victim", Position = new Vector3(0, 0, 10) };

            bool result = authority.ValidateHitPlausibility(attacker, victim, maxWeaponRange: 50f);

            Assert.IsTrue(result, "With nothing blocking the shot, it should be accepted.");
            yield return null;
        }
    }
}
