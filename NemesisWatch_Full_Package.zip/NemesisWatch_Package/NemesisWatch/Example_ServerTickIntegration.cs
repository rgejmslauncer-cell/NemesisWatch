using System;
using System.Collections.Generic;
using NemesisWatch.Behavioral;

namespace NemesisWatch
{
    /// <summary>
    /// Not part of the library — this shows how the pieces fit together
    /// inside whatever tick loop your dedicated server already runs
    /// (Mirror's OnServerUpdate, FishNet's OnTick, a raw socket loop, etc.)
    /// Copy the relevant lines into your real server class.
    /// </summary>
    public class Example_ServerTickIntegration
    {
        private readonly Dictionary<string, PlayerState> _players = new();
        private readonly ServerAuthority _authority = new();
        private readonly EscalationPolicy _escalation = new();
        private readonly VisibilityFilter _visibility = new();
        private readonly BehaviorAnalyzer _behavior = new();
        private readonly HoneypotOpcodeGuard _honeypotOpcodes = new();
        private readonly SaveDataHoneypot _honeypotSaveData = new();

        public Example_ServerTickIntegration()
        {
            // Every violation source feeds the same escalation policy — hard
            // rules, statistical flags, and honeypot hits are all just
            // different confidence levels of the same underlying signal.
            _authority.OnViolation += HandleViolation;
            _behavior.OnBehavioralFlag += HandleViolation;
            _honeypotOpcodes.OnHoneypotTriggered += HandleViolation;
            _honeypotSaveData.OnHoneypotTriggered += HandleViolation;
        }

        private void HandleViolation(Violation violation)
        {
            var action = _escalation.Evaluate(violation);

            Console.WriteLine($"[NemesisWatch] {violation.PlayerId} — {violation.CheckName}: {violation.Details}");

            switch (action)
            {
                case EscalationAction.FlagForReview:
                    // Write to your moderation queue / database here.
                    // Do NOT auto-punish yet — a human (or a later automated
                    // pass) reviews the match replay first.
                    break;

                case EscalationAction.Kick:
                    // KickPlayer(violation.PlayerId, "Anti-cheat: suspicious activity");
                    break;

                case EscalationAction.Ban:
                    // BanAccount(violation.PlayerId, violation.CheckName);
                    break;
            }
        }

        /// <summary>
        /// Called once per server tick for each input received from a client
        /// since the last tick. This is the only place client input is ever
        /// trusted to influence the authoritative game state.
        /// </summary>
        public void OnServerTick(InputCommand input, double serverTime, double deltaTime)
        {
            if (!_players.TryGetValue(input.PlayerId, out var state))
                return; // unknown player, ignore

            _authority.ValidateAndApplyMovement(state, input, serverTime, deltaTime);

            if (input.WantsToFire && _authority.ValidateFireRequest(state, serverTime))
            {
                // Actually spawn the projectile / raycast the shot here —
                // only reached if the fire-rate check passed.
            }

            if (input.WantsToUseAbility && _authority.ValidateAbilityRequest(state, serverTime))
            {
                // Trigger the real ability effect here.
            }
        }

        /// <summary>
        /// Called whenever you're about to send a world-state snapshot to a
        /// specific client (e.g. once per network tick). Only the players
        /// this returns should be written into that client's packet — this
        /// is what actually closes the ESP gap, since a wallhack has nothing
        /// to read if the enemy was never in the data in the first place.
        /// </summary>
        public List<PlayerState> BuildSnapshotFor(string recipientPlayerId)
        {
            if (!_players.TryGetValue(recipientPlayerId, out var observer))
                return new List<PlayerState>();

            return _visibility.GetVisiblePlayersFor(observer, _players.Values);
            // For team games, use GetVisibleEnemiesFor(...) instead and merge
            // the result with an always-visible list of the observer's teammates.
        }

        /// <summary>
        /// Called when your hit-detection logic (server-side raycast, or a
        /// client-claimed hit you're reconciling) determines someone got hit.
        /// </summary>
        public void OnHitEvent(string attackerId, string victimId, float claimedDamage, float weaponRange)
        {
            if (!_players.TryGetValue(attackerId, out var attacker)) return;
            if (!_players.TryGetValue(victimId, out var victim)) return;

            if (!_authority.ValidateHitPlausibility(attacker, victim, weaponRange))
            {
                _behavior.RecordShot(attackerId, hit: false, headshot: false);
                return; // rejected — out of range or blocked by a wall
            }

            _authority.ValidateAndApplyDamage(attacker, victim, claimedDamage, DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0);
            _behavior.RecordShot(attackerId, hit: true, headshot: false); // pass real headshot flag from your hit-location data
        }

        /// <summary>
        /// Call this from wherever your game tracks "a new enemy became
        /// visible/targetable" and "this player fired at them" — e.g. right
        /// after VisibilityFilter reveals a new player to someone, start a
        /// stopwatch, and stop it on their next fire request.
        /// </summary>
        public void OnReactionObserved(string playerId, double millisecondsSinceTargetAppeared)
        {
            _behavior.RecordReactionTime(playerId, millisecondsSinceTargetAppeared);
        }

        /// <summary>
        /// Call this from wherever you already track view rotation per tick
        /// (you likely compute yaw/pitch delta for movement validation
        /// anyway) — pass the rotation this tick and whether the shot that
        /// followed it landed.
        /// </summary>
        public void OnAimRotationObserved(string playerId, double degreesThisTick, bool followedByHit)
        {
            _behavior.RecordAimSnap(playerId, degreesThisTick, followedByHit);
        }

        /// <summary>
        /// Call this from your packet dispatcher for any opcode it doesn't
        /// recognize as a normal gameplay message, before falling back to
        /// generic "unknown packet, drop it" handling.
        /// </summary>
        public void OnUnknownOpcodeReceived(string playerId, int opcodeValue)
        {
            _honeypotOpcodes.CheckIncomingOpcode(playerId, opcodeValue);
        }

        /// <summary>
        /// Call this whenever a client syncs save data, before trusting any
        /// field in it.
        /// </summary>
        public bool OnSaveDataUploaded(SaveDataUpload upload)
        {
            return _honeypotSaveData.Validate(upload);
        }
    }
}
