using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace NemesisWatch.Sdk
{
    /// <summary>
    /// Drop this into a customer's Unity project (server-side build, not the
    /// player's client — never ship your API key inside a player-facing
    /// build, it would let anyone impersonate your customer's traffic).
    /// Wraps every Nemesis Watch Cloud endpoint as a simple coroutine call.
    ///
    /// Usage:
    ///   nemesisWatch.ReportViolation("player123", "Teleport", "Critical", "jumped 40 units");
    ///   nemesisWatch.RecordReaction("player123", 210.0);
    /// </summary>
    public class NemesisWatchClient : MonoBehaviour
    {
        [Header("Nemesis Watch Cloud connection")]
        public string apiBaseUrl = "https://api.nemesiswatch.example.com";
        public string apiKey = "nw_test_key_alpha";

        public event Action<string, string> OnActionReceived; // (playerId, action: LogOnly/FlagForReview/Kick/Ban)

        [Serializable] private class ViolationBody { public string PlayerId, CheckName, Severity, Details; }
        [Serializable] private class ShotBody { public string PlayerId; public bool Hit, Headshot; }
        [Serializable] private class ReactionBody { public string PlayerId; public double Milliseconds; }
        [Serializable] private class AimSnapBody { public string PlayerId; public double DegreesThisTick; public bool FollowedByHit; }
        [Serializable] private class OpcodeBody { public string PlayerId; public int OpcodeValue; }
        [Serializable] private class SaveDataBody { public string PlayerId; public int Coins, Level, LegacyBonusTokens; }
        [Serializable] private class ActionResponse { public string Action; }

        public void ReportViolation(string playerId, string checkName, string severity, string details) =>
            StartCoroutine(Post("/api/v1/violations/report",
                new ViolationBody { PlayerId = playerId, CheckName = checkName, Severity = severity, Details = details }));

        public void RecordShot(string playerId, bool hit, bool headshot) =>
            StartCoroutine(Post("/api/v1/behavior/shot", new ShotBody { PlayerId = playerId, Hit = hit, Headshot = headshot }));

        public void RecordReaction(string playerId, double milliseconds) =>
            StartCoroutine(Post("/api/v1/behavior/reaction", new ReactionBody { PlayerId = playerId, Milliseconds = milliseconds }));

        public void RecordAimSnap(string playerId, double degreesThisTick, bool followedByHit) =>
            StartCoroutine(Post("/api/v1/behavior/aimsnap",
                new AimSnapBody { PlayerId = playerId, DegreesThisTick = degreesThisTick, FollowedByHit = followedByHit }));

        public void CheckOpcode(string playerId, int opcodeValue) =>
            StartCoroutine(Post("/api/v1/honeypot/opcode", new OpcodeBody { PlayerId = playerId, OpcodeValue = opcodeValue }));

        public void CheckSaveData(string playerId, int coins, int level, int legacyBonusTokens) =>
            StartCoroutine(Post("/api/v1/honeypot/savedata",
                new SaveDataBody { PlayerId = playerId, Coins = coins, Level = level, LegacyBonusTokens = legacyBonusTokens }));

        private IEnumerator Post(string path, object body)
        {
            string playerId = ExtractPlayerId(body);
            string json = JsonUtility.ToJson(body);

            using var request = new UnityWebRequest(apiBaseUrl + path, "POST");
            byte[] payload = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(payload);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("X-Api-Key", apiKey);
            request.timeout = 6;

            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogWarning($"[NemesisWatch] Request to {path} failed: {request.error}");
                yield break;
            }

            var response = JsonUtility.FromJson<ActionResponse>(request.downloadHandler.text);
            OnActionReceived?.Invoke(playerId, response?.Action ?? "Unknown");

            // Enforce the result locally the same way regardless of which
            // endpoint produced it — see HandleAction below.
            HandleAction(playerId, response?.Action);
        }

        private static string ExtractPlayerId(object body) => body switch
        {
            ViolationBody v => v.PlayerId,
            ShotBody v => v.PlayerId,
            ReactionBody v => v.PlayerId,
            AimSnapBody v => v.PlayerId,
            OpcodeBody v => v.PlayerId,
            SaveDataBody v => v.PlayerId,
            _ => "unknown"
        };

        /// <summary>
        /// Wire your own kick/ban implementation here. This is deliberately
        /// left as a stub — how you disconnect a player and how you persist
        /// a ban is specific to your game's server framework.
        /// </summary>
        private void HandleAction(string playerId, string action)
        {
            switch (action)
            {
                case "Kick":
                    Debug.Log($"[NemesisWatch] KICK requested for {playerId}");
                    // YourNetworkingFramework.Kick(playerId, "Anti-cheat violation");
                    break;
                case "Ban":
                    Debug.Log($"[NemesisWatch] BAN requested for {playerId}");
                    // YourAccountService.Ban(playerId, "Anti-cheat violation");
                    break;
                case "FlagForReview":
                    Debug.Log($"[NemesisWatch] {playerId} flagged for review — check your dashboard");
                    break;
            }
        }
    }
}
